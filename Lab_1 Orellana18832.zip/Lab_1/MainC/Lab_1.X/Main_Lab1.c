/*
 * File:   main_lab_1.c
 * Author: JOSE EDUARDO ORELLANA
 *UNIVERSIDAD DEL VALLE DE GUATEMALA
 * Created on 22 de enero de 2021, 8:19 PM
 */

// PIC16F887 Configuration 

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// Frecuencia 
#define _XTAL_FREQ   8000000

#include <xc.h>
/*Variable a utilziar para las funciones*/
int start_flag = 0;
void P1(void);
void P2(void);
void Semaforo(void);
void confi(void);
void reset(void);

//Creacion de fucniones a utilizar 

void P1(void) {
    if (PORTA == 0)             //SE UNICIA EN 0
    {
       PORTA = PORTA++; 
    }
    else                        //AL LLAMARLO SE SUMA 1
    {
        PORTA = PORTA << 1;     
        if (PORTAbits.RA7 == 1)// AL LLEGAR AQUI, SIGNIFICA QUE SE ENCEDERA EL IDICADOR Y PAUSARA EL P2
            
        {
            PORTBbits.RB6 = 1; //INDICADOR DE GANADOR P1
            start_flag = 0; //DESHABILITA EL BOTON DEL P2 PARA QUE NO AVANCE MAS 
        }
        else
        {
            PORTBbits.RB6 = 0; // SI NO ES GANADOR NO SE ENCIENDE EL INDICAOR 
        }  
    }
}
 
void P2(void){
    if (PORTC == 0)             
    {
       PORTC = PORTC++; 
    }   
    else                       
    {       
        PORTC = PORTC << 1;     
        if (PORTCbits.RC7 == 1)
        {
            PORTBbits.RB7 = 1; 
            start_flag = 0; // BANDERA QUE NO DEJARA SEGUIR AL P1
        }
        else
        {
            PORTBbits.RB7 = 0; 
        }
    }
}

void Semaforo(void){
    PORTE = 1;                  //CON 100 ms ENTRE SI, SE INICIA EL SEMAFORO.
    __delay_ms(100);
    for (int i=0; i<=2; i++)    //PARA PODER REPETIRLO, LUEGO SE COORE 1.
    {
     PORTE = PORTE << 1;        
     __delay_ms(100);  
    }
   start_flag = 1;
    PORTA = 0;
    PORTB = 0;
    PORTC = 0;
}

void confi(void){
   //PORT A Full Output     
    TRISA = 0;                  
    PORTA = 0;
   //**************************************************************************
   //PORTB primeros 3 INPUTS, sobrantes OutPUts
    TRISB = 0b00001111;         
    PORTB = 0;
   //***************************************************************************
   //PORT C FULL OUTPUTS
    TRISC = 0;                  
    PORTC = 0;
   //***************************************************************************
   //PORTE Full OutPUts
    TRISE = 0;
    PORTE = 0l;
    //**************************************************************************
    ANSEL = 0;                 
    ANSELH = 0;
} 

void reset(void){
  
  //Full clean ports

    PORTA = 0;
    PORTB = 0;
    PORTC = 0;
    PORTE = 0;
    start_flag = 0;
}

//FIN DE FUNCIONES 
//******************************************************************************
    
 //Loop para set de Instrucines 
void main(void) {
    confi();           
    while (1)
    {
        if ((PORTBbits.RB0 == 1) && (!start_flag))      // Push para empezar el semaforo
            
            
        {                                                   
            Semaforo();
        }
        
        if ((PORTBbits.RB1 == 1) && (start_flag))      //PUSH P1, INICIA EL CONTADOR DEL P1 CON SU BANDERA 
        {                                                
            P1();
            __delay_ms(50);                                //DELAY PARA NO TENER EL PROBLEMA "REBTE"
        }
        if ((PORTBbits.RB2 == 1) && (start_flag))     //PUSH P2, INICIA EL CONTADOR DEL P2 CON SU BANDERA 
        {                                               
            P2();
            __delay_ms(50);                             
        }
        if ((PORTBbits.RB3 == 1))                        //LIMPIA TODO PARA PONERLO EN 0 
        {                                                
            reset();
            __delay_ms(50);                             
        }
    }
}
// PUSH BOTONS PROGRMADOS PARA QUE AL PRESIONAR SE ACTIVEN
// Referencias de codigo en libro de arduino, son parecidos ya que arduino se programa en C :D 